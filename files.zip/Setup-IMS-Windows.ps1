# Provigent Inventory Management System - Windows Setup Script
# Usage: Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
#        .\Setup-IMS-Windows.ps1

# Color definitions
$colors = @{
    Green  = 'Green'
    Yellow = 'Yellow'
    Red    = 'Red'
    Cyan   = 'Cyan'
}

# Function to print colored output
function Write-Color {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Message,
        [string]$Color = 'White'
    )
    Write-Host $Message -ForegroundColor $Color
}

# Function to check if command exists
function Test-CommandExists {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Command
    )
    $null = Get-Command $Command -ErrorAction SilentlyContinue
    return $?
}

# Header
Write-Color "======================================" $colors.Cyan
Write-Color "Provigent Inventory Management System" $colors.Cyan
Write-Color "Windows Setup Script" $colors.Cyan
Write-Color "======================================" $colors.Cyan
Write-Host ""

# Check prerequisites
Write-Color "Checking prerequisites..." $colors.Yellow

# Check Python
if (Test-CommandExists python) {
    $pythonVersion = python --version 2>&1
    Write-Color "✓ Python found: $pythonVersion" $colors.Green
} else {
    Write-Color "✗ Python is not installed" $colors.Red
    Write-Color "  Download from: https://www.python.org/downloads/" $colors.Yellow
    exit 1
}

# Check Node.js
if (Test-CommandExists node) {
    $nodeVersion = node --version
    Write-Color "✓ Node.js found: $nodeVersion" $colors.Green
} else {
    Write-Color "✗ Node.js is not installed" $colors.Red
    Write-Color "  Download from: https://nodejs.org/" $colors.Yellow
    exit 1
}

# Check npm
if (Test-CommandExists npm) {
    $npmVersion = npm --version
    Write-Color "✓ npm found: $npmVersion" $colors.Green
} else {
    Write-Color "✗ npm is not installed" $colors.Red
    exit 1
}

# Check git
if (Test-CommandExists git) {
    $gitVersion = git --version
    Write-Color "✓ Git found: $gitVersion" $colors.Green
} else {
    Write-Color "⚠ Git is not installed (optional but recommended)" $colors.Yellow
}

Write-Host ""

# Create or use existing .env file
Write-Color "Setting up environment file..." $colors.Yellow

if (-Not (Test-Path ".env")) {
    if (Test-Path ".env.example") {
        Copy-Item ".env.example" ".env"
        Write-Color "✓ .env file created from .env.example" $colors.Green
        Write-Color "  Please edit .env with your configuration" $colors.Yellow
    } else {
        Write-Color "⚠ .env.example not found" $colors.Yellow
    }
} else {
    Write-Color "✓ .env file already exists" $colors.Green
}

Write-Host ""

# Setup Backend
Write-Color "Setting up Backend (Python)..." $colors.Yellow

# Check if venv exists
if (-Not (Test-Path "venv")) {
    Write-Color "Creating virtual environment..." $colors.Yellow
    python -m venv venv
    Write-Color "✓ Virtual environment created" $colors.Green
} else {
    Write-Color "✓ Virtual environment already exists" $colors.Green
}

# Activate virtual environment
Write-Color "Activating virtual environment..." $colors.Yellow
$activateScript = ".\venv\Scripts\Activate.ps1"

if (Test-Path $activateScript) {
    & $activateScript
    Write-Color "✓ Virtual environment activated" $colors.Green
} else {
    Write-Color "✗ Failed to activate virtual environment" $colors.Red
    exit 1
}

# Install Python dependencies
Write-Color "Installing Python dependencies..." $colors.Yellow
if (Test-Path "requirements.txt") {
    pip install --upgrade pip
    pip install -r requirements.txt
    Write-Color "✓ Python dependencies installed" $colors.Green
} else {
    Write-Color "⚠ requirements.txt not found" $colors.Yellow
}

Write-Host ""

# Setup Frontend
Write-Color "Setting up Frontend (Node.js)..." $colors.Yellow

if (-Not (Test-Path "node_modules")) {
    Write-Color "Installing Node.js dependencies (this may take a few minutes)..." $colors.Yellow
    npm install
    Write-Color "✓ Node.js dependencies installed" $colors.Green
} else {
    Write-Color "✓ Node modules already exist" $colors.Green
}

Write-Host ""

# Create database (SQLite)
Write-Color "Setting up Database..." $colors.Yellow

if (Test-Path "provigent_inventory.db") {
    Write-Color "✓ Database file already exists" $colors.Green
} else {
    Write-Color "Database will be created on first run" $colors.Yellow
}

Write-Host ""

# Completion message
Write-Color "======================================" $colors.Green
Write-Color "Setup Complete!" $colors.Green
Write-Color "======================================" $colors.Green

Write-Host ""
Write-Color "Next Steps:" $colors.Yellow

Write-Host ""
Write-Host "1. Edit .env file with your configuration:"
Write-Host "   • Set SECRET_KEY to a secure random value"
Write-Host "   • Configure DATABASE_URL if using MySQL"
Write-Host ""

Write-Host "2. Start the Backend Server:"
Write-Host "   .\venv\Scripts\Activate.ps1"
Write-Host "   python app.py"
Write-Host ""

Write-Host "3. Open a new PowerShell/CMD and start Frontend Server:"
Write-Host "   npm start"
Write-Host ""

Write-Host "4. Access the application:"
Write-Host "   • Frontend: http://localhost:3000"
Write-Host "   • Backend API: http://localhost:5000"
Write-Host ""

Write-Color "Default Credentials:" $colors.Yellow
Write-Host "   Username: admin"
Write-Host "   Password: admin123"

Write-Host ""
Write-Color "Useful Commands:" $colors.Yellow
Write-Host "   # Create new terminal and activate venv:"
Write-Host "   cd <project-directory>"
Write-Host "   .\venv\Scripts\Activate.ps1"
Write-Host ""

Write-Host "   # Deactivate virtual environment:"
Write-Host "   deactivate"
Write-Host ""

Write-Host "   # Install new Python package:"
Write-Host "   pip install <package-name>"
Write-Host ""

Write-Host "   # Install new Node package:"
Write-Host "   npm install <package-name>"
Write-Host ""

Write-Color "For documentation, see: IMS_END_TO_END_DOCUMENTATION.md" $colors.Yellow

Write-Host ""
Write-Color "Setup script completed successfully!" $colors.Green
