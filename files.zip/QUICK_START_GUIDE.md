# Provigent IMS - Quick Start Guide

Choose your setup path below and follow the steps.

---

## 📋 Table of Contents

- [Quick Start (5 minutes)](#quick-start-5-minutes)
- [Windows Setup](#windows-setup)
- [macOS/Linux Setup](#macoslinu setup)
- [Docker Setup](#docker-setup)
- [Access the Application](#access-the-application)
- [Troubleshooting](#troubleshooting)

---

## Quick Start (5 minutes)

### Prerequisites Check

Ensure you have:
- ✓ Python 3.8+
- ✓ Node.js 14+
- ✓ Git
- ✓ Terminal/PowerShell access

### Step 1: Clone Repository

```bash
git clone https://github.com/kumaraveldharmalingam11cs27-prog/IMS.git
cd IMS
git checkout feature/test
```

### Step 2: Copy Environment File

```bash
cp .env.example .env
```

### Step 3: Run Appropriate Setup

**Choose based on your OS:**

---

## Windows Setup

### Option A: Automated Setup Script (Recommended)

```powershell
# Allow scripts to run
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Run setup script
.\Setup-IMS-Windows.ps1
```

**Then follow the Next Steps provided by the script.**

### Option B: Manual Setup

#### Step 1: Create Virtual Environment
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

#### Step 2: Install Backend Dependencies
```powershell
pip install -r requirements.txt
```

#### Step 3: Install Frontend Dependencies
```powershell
npm install
```

#### Step 4: Start Backend (Terminal 1)
```powershell
.\venv\Scripts\Activate.ps1
python app.py
```

#### Step 5: Start Frontend (Terminal 2)
```powershell
npm start
```

#### Step 6: Access Application
- Frontend: http://localhost:3000
- Backend: http://localhost:5000

---

## macOS/Linux Setup

### Step 1: Create Virtual Environment
```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 2: Install Backend Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Install Frontend Dependencies
```bash
npm install
```

### Step 4: Start Backend (Terminal 1)
```bash
source venv/bin/activate
python app.py
```

#### Expected Output:
```
WARNING in app.runserver: This is a development server. Do not use it in production.
Running on http://127.0.0.1:5000
```

### Step 5: Start Frontend (Terminal 2)
```bash
npm start
```

#### Expected Output:
```
Compiled successfully!
Local: http://localhost:3000
```

### Step 6: Access Application
- Frontend: http://localhost:3000
- Backend: http://localhost:5000

---

## Docker Setup

### Prerequisites
- Docker Desktop installed
- Docker Compose included

### Step 1: Build and Start Services

```bash
docker-compose up -d
```

### Step 2: Wait for Services to Start

```bash
# Check status
docker-compose ps

# View logs
docker-compose logs -f
```

### Step 3: Access Application
- Frontend: http://localhost:3000
- Backend: http://localhost:5000

### Useful Docker Commands

```bash
# View logs
docker-compose logs -f backend
docker-compose logs -f frontend

# Stop services
docker-compose down

# Rebuild services
docker-compose up -d --build

# Remove volumes (reset database)
docker-compose down -v
```

---

## Access the Application

### Login Credentials

- **Username:** admin
- **Password:** admin123

### Default Endpoints

| Component | URL | Port |
|-----------|-----|------|
| Frontend (React) | http://localhost:3000 | 3000 |
| Backend (Flask) | http://localhost:5000 | 5000 |
| API Base | http://localhost:5000/api | 5000 |

### First Login Steps

1. Open http://localhost:3000 in your browser
2. Click "Login"
3. Enter credentials:
   - Username: `admin`
   - Password: `admin123`
4. Click "Sign In"
5. You should see the Dashboard

---

## Common Tasks

### Add Inventory Item

```bash
curl -X POST http://localhost:5000/api/inventory \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <YOUR_TOKEN>" \
  -d '{
    "sku": "SKU-001",
    "name": "Sample Widget",
    "quantity": 100,
    "unit_price": 29.99,
    "min_stock": 10,
    "max_stock": 500
  }'
```

### Get All Inventory Items

```bash
curl -X GET http://localhost:5000/api/inventory \
  -H "Authorization: Bearer <YOUR_TOKEN>"
```

### Create Purchase Order

```bash
curl -X POST http://localhost:5000/api/orders \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <YOUR_TOKEN>" \
  -d '{
    "supplier_id": 1,
    "expected_delivery": "2024-01-22",
    "items": [{"item_id": 1, "quantity": 10}]
  }'
```

---

## Development Workflow

### Making Backend Changes

1. Modify Python files in project root
2. The Flask development server auto-reloads
3. Check terminal for error messages

### Making Frontend Changes

1. Modify React files in `src/`
2. The development server auto-reloads
3. Changes appear instantly in browser

### Database Changes

**For SQLite (default):**
- Database auto-updates when you modify models
- No migration needed for development

**For MySQL (production):**
```bash
# After changing models.py, run:
flask db migrate
flask db upgrade
```

---

## Troubleshooting

### "Python not found" Error

**Windows:**
```powershell
# Check if Python is installed
python --version

# If not, download from https://www.python.org/downloads/
# During installation, CHECK "Add Python to PATH"
```

**macOS/Linux:**
```bash
# Try python3 instead
python3 --version
python3 -m venv venv
```

### "Port 3000 already in use"

**Windows:**
```powershell
# Find and kill process on port 3000
netstat -ano | findstr :3000
taskkill /PID <PID_NUMBER> /F

# Or use different port
SET PORT=3001
npm start
```

**macOS/Linux:**
```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9

# Or use different port
PORT=3001 npm start
```

### "Port 5000 already in use"

**Windows:**
```powershell
# Kill process on port 5000
netstat -ano | findstr :5000
taskkill /PID <PID_NUMBER> /F
```

**macOS/Linux:**
```bash
# Kill process on port 5000
lsof -ti:5000 | xargs kill -9
```

### "Virtual environment not activating" (Windows)

```powershell
# If .\venv\Scripts\Activate.ps1 fails:
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Then try again:
.\venv\Scripts\Activate.ps1

# Or use batch file instead:
.\venv\Scripts\Activate.bat
```

### "ModuleNotFoundError: No module named 'flask'"

```bash
# Activate virtual environment first
# Windows: .\venv\Scripts\Activate.ps1
# macOS/Linux: source venv/bin/activate

# Then install dependencies
pip install -r requirements.txt
```

### "npm ERR! code EACCES" (macOS/Linux)

```bash
# Fix npm permissions
mkdir ~/.npm-global
npm config set prefix '~/.npm-global'
export PATH=~/.npm-global/bin:$PATH

# Then retry
npm install
```

### Cannot Connect to Database

```bash
# Check if .env file exists
cat .env

# Verify DATABASE_URL is set correctly
# For SQLite: sqlite:///provigent_inventory.db
# For MySQL: mysql+pymysql://user:password@host/database
```

### CORS Error in Browser Console

```
Access to XMLHttpRequest from origin 'http://localhost:3000' 
has been blocked by CORS policy
```

**Solution:**
1. Check `.env` file `CORS_ORIGINS` setting
2. Ensure it includes `http://localhost:3000`
3. Restart Flask backend

### Docker Container Not Starting

```bash
# Check logs
docker-compose logs backend
docker-compose logs frontend

# Rebuild
docker-compose down
docker-compose build --no-cache
docker-compose up -d
```

---

## Performance Tips

### Backend Optimization

```python
# Enable caching for frequently accessed data
from flask_caching import Cache
cache = Cache(app, config={'CACHE_TYPE': 'simple'})
```

### Frontend Optimization

```javascript
// Use React.memo for expensive components
const InventoryList = React.memo(({ items }) => {
  return <div>{items.map(item => ...)}</div>;
});
```

### Database Optimization

```sql
-- Add indexes to frequently queried columns
CREATE INDEX idx_sku ON inventory_items(sku);
CREATE INDEX idx_supplier ON orders(supplier_id);
```

---

## Next Steps

After successful setup:

1. **Read Full Documentation**
   - See `IMS_END_TO_END_DOCUMENTATION.md`

2. **Explore API Endpoints**
   - Use Postman or curl to test endpoints
   - Check `API_DOCUMENTATION.md`

3. **Customize Configuration**
   - Edit `.env` file for your environment
   - Update database settings if needed

4. **Add Your Data**
   - Create suppliers
   - Add inventory items
   - Set up purchase orders

5. **Deploy to Production**
   - Follow deployment guide
   - Configure for your infrastructure
   - Set up monitoring and logging

---

## Additional Resources

- **Main Documentation:** `IMS_END_TO_END_DOCUMENTATION.md`
- **API Docs:** `API_DOCUMENTATION.md`
- **Installation Guide:** `INSTALLATION_GUIDE.md`
- **GitHub Repository:** https://github.com/kumaraveldharmalingam11cs27-prog/IMS
- **React Docs:** https://react.dev
- **Flask Docs:** https://flask.palletsprojects.com

---

## Quick Command Reference

### Starting Services

| Command | Purpose |
|---------|---------|
| `python app.py` | Start backend (after activation) |
| `npm start` | Start frontend dev server |
| `docker-compose up -d` | Start all services with Docker |

### Python Virtual Environment

| Command | Purpose |
|---------|---------|
| `python -m venv venv` | Create virtual environment |
| `.\venv\Scripts\Activate.ps1` | Activate (Windows) |
| `source venv/bin/activate` | Activate (macOS/Linux) |
| `deactivate` | Deactivate |
| `pip install -r requirements.txt` | Install dependencies |

### npm Commands

| Command | Purpose |
|---------|---------|
| `npm install` | Install dependencies |
| `npm start` | Start dev server |
| `npm build` | Create production build |
| `npm test` | Run tests |

### Docker Commands

| Command | Purpose |
|---------|---------|
| `docker-compose up -d` | Start services |
| `docker-compose down` | Stop services |
| `docker-compose logs -f` | View logs |
| `docker-compose ps` | Show status |

---

## Support

- **Documentation Issues:** Check `IMS_END_TO_END_DOCUMENTATION.md`
- **API Questions:** See `API_DOCUMENTATION.md`
- **Bug Reports:** Open issue on GitHub
- **Contact:** support@provigent.com

---

**Happy Coding! 🚀**

Last Updated: August 10, 2024
