# npm install - Complete Step-by-Step Guide

Detailed instructions for running `npm install` to set up the frontend dependencies.

---

## Table of Contents

1. [Prerequisites Check](#prerequisites-check)
2. [Step-by-Step npm install](#step-by-step-npm-install)
3. [What Happens During Install](#what-happens-during-install)
4. [Verify Installation](#verify-installation)
5. [Troubleshooting npm install](#troubleshooting-npm-install)
6. [Next Steps](#next-steps)

---

## Prerequisites Check

### Step 1: Verify Node.js is Installed

**Windows (PowerShell):**
```powershell
node --version
npm --version
```

**macOS/Linux (Terminal):**
```bash
node --version
npm --version
```

### Expected Output:

```
v18.17.0  (or any v14+)
9.6.7     (or any 6.0+)
```

### If Command Not Found:

❌ **Error:** `node : The term 'node' is not recognized`

✅ **Solution:** Install Node.js from https://nodejs.org/

1. Download LTS version
2. Run installer
3. Check "Add to PATH" during installation
4. Restart PowerShell/Terminal
5. Try again: `node --version`

---

### Step 2: Verify You're in the Right Directory

**Windows (PowerShell):**
```powershell
# Current directory should show your IMS folder
pwd
# Should show: C:\Users\kveld\Downloads\files
# or C:\Users\YOUR_USERNAME\path-to-IMS

# List files to confirm you're in IMS folder
ls
# Should show: README.md, package.json, src/, public/, etc.
```

**macOS/Linux (Terminal):**
```bash
pwd
# Should show: /Users/username/path-to-IMS
# or /home/username/IMS

ls
# Should show: README.md, package.json, src/, public/, etc.
```

### If You're Not in the Right Folder:

```powershell
# Windows - Navigate to IMS folder
cd c:\Users\kveld\Downloads\files

# Or using the exact path from your setup:
cd "C:\Users\kveld\Downloads\files"
```

```bash
# macOS/Linux
cd ~/path-to-IMS
cd ~/Desktop/IMS
# or wherever you cloned the repo
```

### Step 3: Verify package.json Exists

**Windows (PowerShell):**
```powershell
ls package.json
# Should show: Mode  LastWriteTime   Name
#              ----  -------         ----
#              -a--  8/10/2024       package.json
```

**macOS/Linux (Terminal):**
```bash
ls -la package.json
# Should show: -rw-r--r--  1 user  group  1234 Aug 10 12:34 package.json
```

### If package.json Not Found:

```
Error: No such file or directory
```

❌ You're in the wrong directory!

✅ Make sure you're in the IMS project root folder (same level as package.json)

---

## Step-by-Step npm install

### Step 1: Open Terminal/PowerShell in Project Root

**Windows (PowerShell):**
```powershell
# Navigate to IMS folder
cd c:\Users\kveld\Downloads\files

# Verify you're in the right place
ls package.json  # Should find the file

# You should see something like:
# Mode  LastWriteTime   Name
# ----  -------         ----
# -a--  8/10/2024       package.json
```

**macOS/Linux (Terminal):**
```bash
cd ~/path-to-IMS

# Verify
ls package.json  # Should find the file
```

### Step 2: Clear npm Cache (Optional but Recommended)

This prevents issues with corrupted cache:

```bash
npm cache clean --force
```

**Output:**
```
npm notice as of npm 9.6.7, there is no difference between
npm notice `npm cache clean --force` and `npm cache clean --force`
npm notice
npm notice As of npm v5, the npm cache self-heals from corruption issues
npm notice by default, permanently deleting broken data is not recommended.
npm notice If you want to permanently delete the entire cache, rerun this command
npm notice with --force, or if you prefer to ask npm each time it does this, rerun
npm notice this command with --verify.
npm notice
npm notice It is strongly suggested to verify the integrity of the npm cache
npm notice when making changes to which npm is aware of by running
npm notice
npm notice     npm cache verify
```

### Step 3: Update npm (Optional)

Make sure you have the latest npm:

```bash
npm install -g npm@latest
```

**Output:**
```
changed XX packages in Xs
```

### Step 4: Run npm install

**Windows (PowerShell):**
```powershell
npm install
```

**macOS/Linux (Terminal):**
```bash
npm install
```

**This is the main command - just type it and press Enter!**

### Expected Output During Installation:

```
added 123 packages in 45s

npm warn deprecated ... (some warnings may appear - these are usually OK)

up to date, audited 123 packages in 5s

2 vulnerabilities (1 moderate, 1 high)
```

---

## What Happens During Install

### Phase 1: Download Dependencies (1-2 minutes)

**What you see:**
```
npm WARN deprecated ...
npm WARN deprecated ...
npm notice ...
```

✅ This is normal - warnings about deprecated packages are not critical for development

### Phase 2: Extract and Install (2-3 minutes)

**What you see:**
```
added 123 packages
added 456 packages
added 789 packages
```

✅ Dependencies are being extracted and installed

### Phase 3: Verify Installation (30-60 seconds)

**What you see:**
```
up to date, audited 123 packages in 5s

2 vulnerabilities (1 moderate, 1 high)
```

✅ Installation is complete - vulnerabilities are usually acceptable for development

### Phase 4: Completion

**Final line:**
```
added 123 packages in 45s
```

✅ **SUCCESS!** The prompt returns, ready for next command

---

## Timeline

| Phase | Duration | What's Happening |
|-------|----------|-----------------|
| 1. Dependency Resolution | 10-20 sec | npm reads package.json |
| 2. Package Download | 20-60 sec | Files downloaded from npm registry |
| 3. Extraction & Install | 30-120 sec | Files extracted, installed |
| 4. Verification | 5-15 sec | npm verifies installation |
| 5. Ready | Instant | Prompt returns |
| **Total Time** | **1-5 minutes** | Depends on internet speed |

---

## Verify Installation

### Step 1: Check node_modules Folder

**Windows (PowerShell):**
```powershell
# Check if node_modules folder exists
ls node_modules

# Count installed packages
(ls node_modules | Measure-Object).Count
# Should show: 200+ folders
```

**macOS/Linux (Terminal):**
```bash
# Check if node_modules folder exists
ls -la node_modules | head -20

# Count installed packages
ls node_modules | wc -l
# Should show: 200+
```

### Expected Output:

```
Mode  LastWriteTime        Name
----  -------              ----
d----  8/10/2024 12:34 PM  .bin
d----  8/10/2024 12:34 PM  .package-lock.json
d----  8/10/2024 12:34 PM  @babel
d----  8/10/2024 12:34 PM  @testing-library
d----  8/10/2024 12:34 PM  react
d----  8/10/2024 12:34 PM  react-dom
d----  8/10/2024 12:34 PM  axios
d----  8/10/2024 12:34 PM  web-vitals
... (many more folders)
```

### Step 2: Check package-lock.json

**Windows (PowerShell):**
```powershell
ls package-lock.json

# You should see it's been created/updated
# Mode  LastWriteTime        Name
# ----  -------              ----
# -a--  8/10/2024 12:34 PM  package-lock.json
```

**macOS/Linux (Terminal):**
```bash
ls -la package-lock.json
# You should see it's been created/updated
```

### Step 3: Verify Key Dependencies

Check that main packages are installed:

**Windows (PowerShell):**
```powershell
# Check for React
ls node_modules/react

# Check for React DOM
ls node_modules/react-dom

# Check for Axios
ls node_modules/axios
```

**macOS/Linux (Terminal):**
```bash
# Check for React
ls node_modules/react

# Check for React DOM
ls node_modules/react-dom

# Check for Axios
ls node_modules/axios
```

### Expected Output:

```
Mode  LastWriteTime        Name
----  -------              ----
d----  8/10/2024 12:34 PM  package.json
d----  8/10/2024 12:34 PM  README.md
d----  8/10/2024 12:34 PM  index.d.ts
d----  8/10/2024 12:34 PM  index.js
d----  8/10/2024 12:34 PM  package.json
```

### Step 4: Test npm Works

Run a simple npm command:

```bash
npm list react
```

**Expected Output:**
```
[email protected] /Users/username/IMS
└── [email protected]
```

✅ This confirms React is installed and npm can find it.

---

## Troubleshooting npm install

### Issue 1: "npm: command not found"

**Problem:**
```
bash: npm: command not found
```

**Cause:** Node.js/npm not installed or not in PATH

**Solution:**

**Windows:**
1. Download from https://nodejs.org/
2. Run installer
3. Check "Add to PATH" during installation
4. Restart PowerShell
5. Try: `npm --version`

**macOS:**
```bash
# Install using Homebrew
brew install node

# Or download from https://nodejs.org/
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get update
sudo apt-get install nodejs npm

# Verify
npm --version
```

---

### Issue 2: "npm ERR! 404 Not Found"

**Problem:**
```
npm ERR! 404 Not Found - GET https://registry.npmjs.org/some-package
npm ERR! 404 
npm ERR! 404  'some-package' is not in this registry.
```

**Cause:** 
- Package doesn't exist
- Network issue
- npm registry is down

**Solution 1: Check Internet Connection**
```bash
# Test connectivity
ping registry.npmjs.org

# If no response, check your internet
```

**Solution 2: Change npm Registry**
```bash
# Use official registry
npm set registry https://registry.npmjs.org/

# Then retry
npm install
```

**Solution 3: Clear Cache and Retry**
```bash
npm cache clean --force
npm install
```

---

### Issue 3: "npm ERR! code EACCES" (macOS/Linux)

**Problem:**
```
npm ERR! code EACCES
npm ERR! syscall mkdir
npm ERR! path /usr/local/lib/node_modules
npm ERR! errno -13
npm ERR! Error: EACCES: permission denied
```

**Cause:** Permission issue with npm directory

**Solution:**

```bash
# Option 1: Create npm directory with correct permissions
mkdir ~/.npm-global
npm config set prefix '~/.npm-global'

# Add to PATH
export PATH=~/.npm-global/bin:$PATH

# Then retry
npm install
```

**Option 2: Use sudo (not recommended)**
```bash
sudo npm install
```

---

### Issue 4: "npm WARN tar" Warnings

**Problem:**
```
npm WARN tar invalid entry found in archive (package-lock.json)
npm WARN tar invalid entry found in archive
```

**Cause:** Corrupted cache

**Solution:**
```bash
# Clear cache
npm cache clean --force

# Delete node_modules and package-lock.json
rm -rf node_modules package-lock.json

# Reinstall
npm install
```

---

### Issue 5: "npm install" Hangs

**Problem:**
```
# Command appears to hang, no progress for 5+ minutes
```

**Cause:**
- Network issue
- npm registry slow
- Large package taking time

**Solution 1: Wait (Usually Works)**
```bash
# Wait 10-15 minutes, npm may be downloading large packages
# Ctrl+C to cancel after 15 minutes if no progress
```

**Solution 2: Increase Timeout**
```bash
npm install --fetch-timeout=120000 --fetch-retry-mintimeout=20000
```

**Solution 3: Use npm ci (Cleaner Install)**
```bash
npm ci  # Instead of npm install
# This uses package-lock.json directly
```

**Solution 4: Try Different Registry**
```bash
npm set registry https://registry.npmmirror.com
npm install

# Switch back to default
npm set registry https://registry.npmjs.org/
```

---

### Issue 6: "npm WARN vulnerabilities"

**Problem:**
```
up to date, audited 123 packages in 5s

2 vulnerabilities (1 moderate, 1 high)
```

**Cause:** Some packages have security vulnerabilities

**For Development:** ✅ This is FINE - you can ignore

**For Production:** ⚠️ Fix with:
```bash
npm audit fix
```

---

### Issue 7: Port 3000 Already in Use

**Problem:**
After npm install, when running `npm start`:
```
Port 3000 is already in use
```

**Solution (Windows):**
```powershell
# Find what's using port 3000
netstat -ano | findstr :3000

# Kill the process (replace PID with the number shown)
taskkill /PID 12345 /F

# Or use different port
SET PORT=3001
npm start
```

**Solution (macOS/Linux):**
```bash
# Find what's using port 3000
lsof -i :3000

# Kill the process
kill -9 <PID>

# Or use different port
PORT=3001 npm start
```

---

### Issue 8: Module Not Found After Install

**Problem:**
After npm install, running `npm start`:
```
Module not found: Error: Can't resolve 'react'
```

**Cause:** npm install didn't complete properly

**Solution:**
```bash
# Delete node_modules and package-lock.json
rm -rf node_modules package-lock.json

# Clear cache
npm cache clean --force

# Reinstall
npm install

# Verify React is installed
npm list react
```

---

## Success Checklist

After npm install, verify:

- [ ] Command completed (prompt returned)
- [ ] No critical errors (warnings are OK)
- [ ] `node_modules` folder exists and has 200+ folders
- [ ] `package-lock.json` file exists
- [ ] Can run: `npm list react` successfully
- [ ] Can run: `npm test` without errors
- [ ] Can run: `npm start` (frontend starts on port 3000)

---

## Next Steps After npm install

### Option 1: Start Frontend Server

**Windows (PowerShell):**
```powershell
npm start
```

**macOS/Linux (Terminal):**
```bash
npm start
```

**Expected Output:**
```
Compiled successfully!

On Your Network: http://192.168.x.x:3000
Local: http://localhost:3000

Press q to quit, s to stop the watcher
```

✅ Open browser to http://localhost:3000

### Option 2: Run Tests

```bash
npm test
```

### Option 3: Build for Production

```bash
npm run build
```

This creates an optimized production build in the `build/` folder.

---

## Quick Reference

### Common npm Commands

| Command | Purpose | Time |
|---------|---------|------|
| `npm install` | Install all dependencies | 1-5 min |
| `npm install <package>` | Install specific package | 10-30 sec |
| `npm start` | Start development server | Instant |
| `npm test` | Run tests | 30-60 sec |
| `npm build` | Create production build | 30-60 sec |
| `npm cache clean --force` | Clear npm cache | 5-10 sec |
| `npm list` | List installed packages | 1-2 sec |

---

## Detailed Troubleshooting Flowchart

```
npm install error?
│
├─ "npm not found"
│  └─ Install Node.js from nodejs.org
│
├─ "404 Not Found"
│  └─ Check internet, change registry
│
├─ "EACCES permission denied"
│  └─ Fix npm permissions (Linux/Mac)
│
├─ "Hangs/Freezes"
│  └─ Wait 10-15 min OR increase timeout
│
├─ "Vulnerabilities warning"
│  └─ For dev: ignore, For prod: npm audit fix
│
└─ "Module not found after install"
   └─ Delete node_modules, npm cache clean, reinstall
```

---

## Performance Tips

### For Faster Installation

```bash
# Use npm ci instead of npm install
# (if package-lock.json exists)
npm ci

# This is faster because it doesn't calculate dependencies
```

### For Multiple Projects

```bash
# Set up global npm directory once
npm config set prefix '~/.npm-global'

# Then npm install will be faster for subsequent projects
```

### Monitor Installation Progress

```bash
# Show detailed progress
npm install --loglevel verbose

# Or
npm install --loglevel silly  # Very detailed
```

---

## Common Mistakes to Avoid

❌ **Don't:**
- Run npm install in wrong directory
- Install system-wide with `sudo npm install`
- Manually delete node_modules without reinstalling
- Ignore the package-lock.json file

✅ **Do:**
- Verify you're in the project root (with package.json)
- Use `npm ci` for exact versions if package-lock.json exists
- Keep node_modules out of version control (it's in .gitignore)
- Commit package-lock.json to git

---

## System Requirements Recap

For npm install to work, you need:

- ✅ Node.js 14+ (v18+ recommended)
- ✅ npm 6+ (automatically installed with Node.js)
- ✅ 500MB free disk space
- ✅ Internet connection (to download packages)
- ✅ Located in project root directory

---

## Getting Help

If npm install still fails:

1. **Check error message carefully** - first line usually says the problem
2. **Search error on Google** - include `npm` and the error code
3. **Try on different network** - if internet issue
4. **Reinstall Node.js** - if npm is corrupted
5. **Check documentation** - https://docs.npmjs.com/

---

## Quick Reference Commands

### Copy-Paste Ready:

```bash
# Full cleanup and reinstall
rm -rf node_modules package-lock.json
npm cache clean --force
npm install

# Windows version:
rmdir /s node_modules
del package-lock.json
npm cache clean --force
npm install
```

---

**Last Updated:** August 10, 2024

**Next Step:** After npm install completes, run `npm start` to start the development server!
