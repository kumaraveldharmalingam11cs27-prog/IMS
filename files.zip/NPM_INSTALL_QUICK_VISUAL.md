# npm install - Visual Quick Guide

## 🚀 Complete npm install in 5 Steps

---

## STEP 1️⃣: Check Prerequisites

```
✓ Node.js installed?
  → Open PowerShell/Terminal
  → Type: node --version
  → Should see: v14+ or v18+

✓ npm installed?
  → Type: npm --version
  → Should see: 6+ or 9+

✗ NOT installed?
  → Download: https://nodejs.org/
  → Install with "Add to PATH" checked
  → Restart PowerShell/Terminal
  → Try: node --version again
```

---

## STEP 2️⃣: Navigate to Project

### Windows (PowerShell):
```powershell
cd c:\Users\kveld\Downloads\files

# Verify you're in right place
ls package.json
# Should see the file listed
```

### macOS/Linux (Terminal):
```bash
cd ~/path-to-IMS

# Verify
ls package.json
# Should see the file listed
```

**✅ If package.json is found, you're in the right place!**

---

## STEP 3️⃣: Clean npm Cache (Optional)

```bash
npm cache clean --force
```

**Output:**
```
✓ Cache cleaned
```

---

## STEP 4️⃣: Run npm install

### Windows (PowerShell):
```powershell
npm install
```

### macOS/Linux (Terminal):
```bash
npm install
```

**⏱️ Wait 1-5 minutes...**

### What You'll See:

```
npm notice creating a default package.json
npm notice creating a default .npmrc
npm notice...
npm WARN...
npm WARN...

added 123 packages in 45s

up to date, audited 123 packages in 5s

2 vulnerabilities (1 moderate, 1 high)
```

**✅ This is normal! Warnings are OK.**

---

## STEP 5️⃣: Verify Installation

### Check node_modules folder exists:

**Windows:**
```powershell
ls node_modules | Measure-Object
# Should show: Count = 200+
```

**macOS/Linux:**
```bash
ls node_modules | wc -l
# Should show: 200+
```

### Verify React is installed:

```bash
npm list react
```

**Output:**
```
[email protected] /Users/username/IMS
└── [email protected]
```

✅ **SUCCESS!** npm install is complete.

---

## 📊 Installation Timeline

```
Step          Duration      Status
────────────────────────────────────
1. Start          0 sec      🔴 Running
2. Download    20-60 sec     🟡 Downloading...
3. Extract    30-120 sec     🟡 Extracting...
4. Verify      5-15 sec      🟡 Verifying...
5. Complete      Done        ✅ Complete
────────────────────────────────────
Total       1-5 minutes
```

---

## 🎯 What Gets Installed

```
node_modules/ (created)
├── react/              ← Frontend framework
├── react-dom/          ← React rendering
├── axios/              ← HTTP client
├── @testing-library/   ← Testing tools
├── web-vitals/         ← Performance metrics
└── ... (200+ total)

package-lock.json (created/updated)
└── Locks exact versions
```

---

## ⚠️ Common Issues & Fixes

### Issue: "npm: command not found"
```
❌ Problem: Node.js not installed
✅ Fix: Install from https://nodejs.org/
        Make sure to check "Add to PATH"
```

### Issue: Hangs or freezes
```
❌ Problem: Slow download or network issue
✅ Fix: Wait 10-15 minutes
        Or: npm install --fetch-timeout=120000
```

### Issue: "Permission denied" (Mac/Linux)
```
❌ Problem: npm directory permissions
✅ Fix: mkdir ~/.npm-global
        npm config set prefix '~/.npm-global'
```

### Issue: "404 Not Found"
```
❌ Problem: Network or package issue
✅ Fix: npm cache clean --force
        npm install
```

### Issue: Wrong directory
```
❌ Problem: Not in IMS folder
✅ Fix: ls package.json (should find it)
        If not found, cd to correct directory
```

---

## ✅ Success Checklist

After npm install, you should have:

- ✅ No critical errors (warnings are OK)
- ✅ Prompt returned (not hanging)
- ✅ `node_modules/` folder with 200+ items
- ✅ `package-lock.json` file exists
- ✅ `npm list react` shows [email protected]
- ✅ Ready to run `npm start`

---

## 🚀 Next Steps

### Start Development Server:

```bash
npm start
```

**Expected:**
```
Compiled successfully!

On Your Network: http://192.168.x.x:3000
Local: http://localhost:3000
```

✅ Open http://localhost:3000 in browser

---

## 📋 Command Cheat Sheet

| What to Do | Windows | macOS/Linux |
|-----------|---------|-------------|
| **Check node** | `node --version` | `node --version` |
| **Check npm** | `npm --version` | `npm --version` |
| **Navigate** | `cd c:\path\IMS` | `cd ~/path/IMS` |
| **Clean cache** | `npm cache clean --force` | `npm cache clean --force` |
| **Install deps** | `npm install` | `npm install` |
| **Verify** | `npm list react` | `npm list react` |
| **Start server** | `npm start` | `npm start` |
| **Run tests** | `npm test` | `npm test` |
| **Build prod** | `npm run build` | `npm run build` |

---

## 🔄 If Install Fails - Reset & Retry

### Complete Reset:

**Windows:**
```powershell
# Delete everything npm created
rmdir /s node_modules
del package-lock.json

# Clean cache
npm cache clean --force

# Fresh install
npm install
```

**macOS/Linux:**
```bash
# Delete everything npm created
rm -rf node_modules
rm package-lock.json

# Clean cache
npm cache clean --force

# Fresh install
npm install
```

---

## 📞 Still Having Issues?

1. **Detailed Guide:** Read `NPM_INSTALL_STEP_BY_STEP.md`
2. **Troubleshooting:** Check `TESTING_AND_TROUBLESHOOTING.md`
3. **Full Docs:** See `IMS_END_TO_END_DOCUMENTATION.md`

---

## 💡 Pro Tips

✨ **Faster Install Next Time:**
```bash
npm ci  # Uses package-lock.json for faster install
```

✨ **Show Progress:**
```bash
npm install --verbose
```

✨ **Install Specific Package:**
```bash
npm install react-router  # Adds new package
```

✨ **Update All Packages:**
```bash
npm update
```

---

## 🎓 Understanding npm install

```
package.json
    ↓
    Reads list of dependencies needed
    ↓
npm registry (npmjs.com)
    ↓
    Downloads packages & their dependencies
    ↓
node_modules/ folder
    ↓
    All packages installed and ready to use
    ↓
package-lock.json
    ↓
    Records exact versions for future installs
```

---

## Timeline: What Happens When

```
Second 0-5:      npm reads package.json
Second 5-30:     Resolves dependencies
Second 30-90:    Downloads all packages
Second 90-180:   Extracts and installs files
Second 180-210:  Verifies installation
Second 210+:     Complete! ✅
```

---

## System Requirements

- ✅ Node.js 14+ (v18 recommended)
- ✅ npm 6+ (comes with Node.js)
- ✅ 500MB+ free disk space
- ✅ Internet connection
- ✅ 2GB+ RAM

---

## 🎯 One-Command Setup

After cloning IMS repository:

**Windows:**
```powershell
npm cache clean --force; npm install
```

**macOS/Linux:**
```bash
npm cache clean --force && npm install
```

---

**Status: READY TO GO! 🚀**

Next: `npm start` to run the frontend server

See `QUICK_START_GUIDE.md` for complete setup
