# Provigent IMS - Testing & Troubleshooting Guide

Complete guide for testing the application and resolving common issues.

---

## Table of Contents

1. [Testing Strategy](#testing-strategy)
2. [Backend Testing](#backend-testing)
3. [Frontend Testing](#frontend-testing)
4. [API Testing](#api-testing)
5. [Database Testing](#database-testing)
6. [Integration Testing](#integration-testing)
7. [Troubleshooting](#troubleshooting)
8. [Performance Testing](#performance-testing)
9. [Security Testing](#security-testing)

---

## Testing Strategy

### Test Pyramid

```
        ┌─────────────┐
        │  E2E Tests  │  (10%)
        ├─────────────┤
        │  API Tests  │  (30%)
        ├─────────────┤
        │ Unit Tests  │  (60%)
        └─────────────┘
```

### Test Coverage Goals

- **Unit Tests:** 80%+ coverage
- **Integration Tests:** 100% of API endpoints
- **E2E Tests:** Critical user workflows

---

## Backend Testing

### Unit Testing Setup

#### 1. Install Testing Dependencies

```bash
# Activate virtual environment
source venv/bin/activate  # macOS/Linux
# or
.\venv\Scripts\Activate.ps1  # Windows

# Install test dependencies
pip install pytest pytest-cov pytest-flask pytest-mock
```

#### 2. Create Test File Structure

```
backend/
├── tests/
│   ├── __init__.py
│   ├── conftest.py
│   ├── test_models.py
│   ├── test_routes_auth.py
│   ├── test_routes_inventory.py
│   ├── test_routes_orders.py
│   └── test_routes_suppliers.py
├── app.py
└── models.py
```

#### 3. Create conftest.py (Fixtures)

```python
# tests/conftest.py
import pytest
from app import app, db
from models import User, InventoryItem

@pytest.fixture
def client():
    """Create test client"""
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    with app.app_context():
        db.create_all()
        yield app.test_client()
        db.session.remove()
        db.drop_all()

@pytest.fixture
def auth_headers(client):
    """Get authorization headers with JWT token"""
    response = client.post('/api/auth/login', json={
        'username': 'testuser',
        'password': 'testpass123'
    })
    token = response.json['data']['access_token']
    return {'Authorization': f'Bearer {token}'}
```

#### 4. Write Unit Tests

**Example: test_routes_auth.py**

```python
# tests/test_routes_auth.py
import pytest

class TestAuthentication:
    """Test authentication endpoints"""
    
    def test_register_user(self, client):
        """Test user registration"""
        response = client.post('/api/auth/register', json={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'testpass123'
        })
        
        assert response.status_code == 201
        assert response.json['success'] == True
        assert response.json['data']['username'] == 'testuser'
    
    def test_login_user(self, client):
        """Test user login"""
        # First create a user
        client.post('/api/auth/register', json={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'testpass123'
        })
        
        # Then login
        response = client.post('/api/auth/login', json={
            'username': 'testuser',
            'password': 'testpass123'
        })
        
        assert response.status_code == 200
        assert 'access_token' in response.json['data']
    
    def test_login_invalid_credentials(self, client):
        """Test login with invalid credentials"""
        response = client.post('/api/auth/login', json={
            'username': 'nonexistent',
            'password': 'wrongpass'
        })
        
        assert response.status_code == 401
        assert response.json['success'] == False
```

**Example: test_routes_inventory.py**

```python
# tests/test_routes_inventory.py
import pytest

class TestInventory:
    """Test inventory endpoints"""
    
    def test_get_inventory(self, client, auth_headers):
        """Test getting inventory items"""
        response = client.get('/api/inventory', headers=auth_headers)
        
        assert response.status_code == 200
        assert response.json['success'] == True
        assert isinstance(response.json['data'], list)
    
    def test_create_inventory_item(self, client, auth_headers):
        """Test creating inventory item"""
        response = client.post('/api/inventory', 
            json={
                'sku': 'SKU-001',
                'name': 'Test Widget',
                'quantity': 100,
                'unit_price': 29.99
            },
            headers=auth_headers
        )
        
        assert response.status_code == 201
        assert response.json['data']['sku'] == 'SKU-001'
    
    def test_create_duplicate_sku(self, client, auth_headers):
        """Test that duplicate SKUs are rejected"""
        # Create first item
        client.post('/api/inventory',
            json={
                'sku': 'SKU-001',
                'name': 'Item 1',
                'quantity': 100,
                'unit_price': 29.99
            },
            headers=auth_headers
        )
        
        # Try to create second item with same SKU
        response = client.post('/api/inventory',
            json={
                'sku': 'SKU-001',
                'name': 'Item 2',
                'quantity': 50,
                'unit_price': 19.99
            },
            headers=auth_headers
        )
        
        assert response.status_code == 400
        assert response.json['success'] == False
```

#### 5. Run Tests

```bash
# Run all tests
pytest

# Run with verbose output
pytest -v

# Run specific test file
pytest tests/test_routes_auth.py

# Run specific test
pytest tests/test_routes_auth.py::TestAuthentication::test_login_user

# Generate coverage report
pytest --cov=. --cov-report=html

# Run with output
pytest -s
```

#### Expected Output

```
tests/test_routes_auth.py::TestAuthentication::test_register_user PASSED    [ 10%]
tests/test_routes_auth.py::TestAuthentication::test_login_user PASSED       [ 20%]
tests/test_routes_auth.py::TestAuthentication::test_login_invalid_credentials PASSED [ 30%]
tests/test_routes_inventory.py::TestInventory::test_get_inventory PASSED    [ 40%]

====== 4 passed in 0.12s ======
```

---

## Frontend Testing

### React Component Testing

#### 1. Install Testing Libraries

```bash
npm install --save-dev @testing-library/react @testing-library/jest-dom @testing-library/user-event
npm install --save-dev jest jest-environment-jsdom
```

#### 2. Create Test File

**Example: src/components/InventoryList.test.jsx**

```jsx
import { render, screen, fireEvent } from '@testing-library/react';
import InventoryList from './InventoryList';

describe('InventoryList Component', () => {
  const mockItems = [
    { id: 1, sku: 'SKU-001', name: 'Widget A', quantity: 100 },
    { id: 2, sku: 'SKU-002', name: 'Widget B', quantity: 50 }
  ];

  test('renders inventory items', () => {
    render(<InventoryList items={mockItems} />);
    
    expect(screen.getByText('Widget A')).toBeInTheDocument();
    expect(screen.getByText('Widget B')).toBeInTheDocument();
  });

  test('displays correct quantity', () => {
    render(<InventoryList items={mockItems} />);
    
    const quantities = screen.getAllByText(/\d+/);
    expect(quantities).toHaveLength(2);
  });

  test('calls onDelete when delete button clicked', () => {
    const mockDelete = jest.fn();
    render(<InventoryList items={mockItems} onDelete={mockDelete} />);
    
    const deleteButtons = screen.getAllByRole('button', { name: /delete/i });
    fireEvent.click(deleteButtons[0]);
    
    expect(mockDelete).toHaveBeenCalledWith(1);
  });
});
```

#### 3. Run Component Tests

```bash
# Run all tests
npm test

# Run in watch mode
npm test -- --watch

# Run specific test file
npm test -- InventoryList.test.jsx

# Generate coverage
npm test -- --coverage
```

---

## API Testing

### Manual API Testing with curl

#### 1. Register User

```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "testpass123"
  }'
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "username": "testuser",
    "email": "test@example.com"
  },
  "message": "User registered successfully"
}
```

#### 2. Login User

```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "password": "testpass123"
  }'
```

**Save the token from response:**
```bash
TOKEN="eyJhbGciOiJIUzI1NiIs..."
```

#### 3. Test Protected Endpoint

```bash
curl -X GET http://localhost:5000/api/inventory \
  -H "Authorization: Bearer $TOKEN"
```

#### 4. Create Inventory Item

```bash
curl -X POST http://localhost:5000/api/inventory \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "sku": "SKU-001",
    "name": "Test Widget",
    "description": "A test widget",
    "quantity": 100,
    "min_stock": 20,
    "max_stock": 500,
    "unit_price": 29.99,
    "category": "Hardware",
    "location": "Warehouse A"
  }'
```

### Postman Testing

#### 1. Import API Collection

1. Open Postman
2. Click "Import"
3. Select "Link"
4. Paste API documentation URL

#### 2. Set Environment Variables

1. Create new environment: "Development"
2. Add variables:
   - `base_url`: `http://localhost:5000`
   - `token`: (will be filled after login)

#### 3. Create Test Requests

**Register Request:**
- Method: POST
- URL: `{{base_url}}/api/auth/register`
- Body (raw JSON):
```json
{
  "username": "postman_test",
  "email": "postman@test.com",
  "password": "testpass123"
}
```

**Login Request:**
- Method: POST
- URL: `{{base_url}}/api/auth/login`
- Body:
```json
{
  "username": "postman_test",
  "password": "testpass123"
}
```
- Tests (tab):
```javascript
// Save token for later use
if (pm.response.code === 200) {
  var jsonData = pm.response.json();
  pm.environment.set("token", jsonData.data.access_token);
}
```

**Get Inventory Request:**
- Method: GET
- URL: `{{base_url}}/api/inventory`
- Headers:
  - Key: `Authorization`
  - Value: `Bearer {{token}}`

---

## Database Testing

### Test Database Operations

#### 1. Test SQLite Connection

```bash
# Check if database file exists
ls -la provigent_inventory.db  # macOS/Linux
dir provigent_inventory.db     # Windows

# Query database
python3 -c "
import sqlite3
conn = sqlite3.connect('provigent_inventory.db')
cursor = conn.cursor()
cursor.execute('SELECT name FROM sqlite_master WHERE type=\"table\"')
print(cursor.fetchall())
conn.close()
"
```

#### 2. Verify Tables

```bash
python3 << 'EOF'
from app import app, db
from models import User, InventoryItem, Supplier, Order

with app.app_context():
    # Check all tables
    print("Tables in database:")
    for table in db.metadata.tables:
        print(f"  - {table}")
    
    # Count records in each table
    print("\nRecord counts:")
    print(f"  Users: {User.query.count()}")
    print(f"  Items: {InventoryItem.query.count()}")
    print(f"  Suppliers: {Supplier.query.count()}")
    print(f"  Orders: {Order.query.count()}")
EOF
```

#### 3. Test Data Integrity

```bash
python3 << 'EOF'
from app import app, db
from models import InventoryItem

with app.app_context():
    # Check for items with null required fields
    items = InventoryItem.query.filter(
        (InventoryItem.sku == None) | (InventoryItem.name == None)
    ).all()
    
    if items:
        print(f"Found {len(items)} items with missing required fields")
    else:
        print("✓ All items have required fields")
    
    # Check for invalid quantities
    invalid = InventoryItem.query.filter(
        InventoryItem.quantity < 0
    ).all()
    
    if invalid:
        print(f"Found {len(invalid)} items with negative quantity")
    else:
        print("✓ All quantities are valid")
EOF
```

---

## Integration Testing

### End-to-End Workflow Test

#### Complete User Journey

```bash
#!/bin/bash

BASE_URL="http://localhost:5000"
REGISTER_RESPONSE=$(curl -s -X POST $BASE_URL/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "e2e_test",
    "email": "e2e@test.com",
    "password": "testpass123"
  }')

echo "1. Register User: $REGISTER_RESPONSE"

LOGIN_RESPONSE=$(curl -s -X POST $BASE_URL/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "e2e_test",
    "password": "testpass123"
  }')

TOKEN=$(echo $LOGIN_RESPONSE | grep -o '"access_token":"[^"]*' | cut -d'"' -f4)
echo "2. Login Token: $TOKEN"

# Create supplier
SUPPLIER_RESPONSE=$(curl -s -X POST $BASE_URL/api/suppliers \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "Test Supplier",
    "contact_email": "supplier@test.com",
    "lead_time_days": 7
  }')

echo "3. Create Supplier: $SUPPLIER_RESPONSE"

# Create inventory item
ITEM_RESPONSE=$(curl -s -X POST $BASE_URL/api/inventory \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "sku": "SKU-E2E",
    "name": "E2E Test Item",
    "quantity": 100,
    "unit_price": 29.99
  }')

echo "4. Create Item: $ITEM_RESPONSE"

# Create order
ORDER_RESPONSE=$(curl -s -X POST $BASE_URL/api/orders \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "supplier_id": 1,
    "expected_delivery": "2024-01-30",
    "items": [{"item_id": 1, "quantity": 10}]
  }')

echo "5. Create Order: $ORDER_RESPONSE"
```

---

## Troubleshooting

### Issue 1: Application Won't Start

#### Symptoms
```
Error: Address already in use
Error: ModuleNotFoundError
Error: Database connection failed
```

#### Diagnosis Steps

```bash
# Check Python installation
python --version
python -c "import flask; print(flask.__version__)"

# Check if dependencies are installed
pip list | grep Flask

# Check if virtual environment is activated
# Should show (venv) in terminal prompt
which python  # macOS/Linux - should show /path/to/venv/bin/python

# Check if port is in use
# Windows:
netstat -ano | findstr :5000
# macOS/Linux:
lsof -i :5000

# Check .env file
cat .env
```

#### Solutions

```bash
# If virtual environment not activated:
source venv/bin/activate  # macOS/Linux
.\venv\Scripts\Activate.ps1  # Windows

# If dependencies missing:
pip install -r requirements.txt

# If port already in use:
# Kill process or use different port
export FLASK_RUN_PORT=5001  # or SET FLASK_RUN_PORT=5001 on Windows

# If database issue:
rm provigent_inventory.db  # Delete and recreate
python app.py
```

### Issue 2: Frontend Won't Connect to Backend

#### Symptoms
```
Error: Failed to fetch
Error: Could not connect to api
CORS error in console
```

#### Diagnosis Steps

```bash
# Check if backend is running
curl http://localhost:5000/api/inventory

# Check CORS configuration
# In app.py, verify CORS is enabled

# Check frontend .env
cat .env | grep REACT_APP_API_URL

# Check network connection
ping localhost
```

#### Solutions

```bash
# Ensure backend is running on correct port
python app.py

# Update .env with correct API URL
REACT_APP_API_URL=http://localhost:5000

# Restart frontend
npm start

# Clear browser cache
# Ctrl+Shift+Delete (Windows/Linux)
# Cmd+Shift+Delete (macOS)
```

### Issue 3: Database Connection Error

#### Symptoms
```
Error: Can't connect to MySQL server
Error: No such file or directory
Error: database is locked
```

#### Diagnosis Steps

```bash
# Check SQLite file
ls -la provigent_inventory.db

# Check SQLite integrity
sqlite3 provigent_inventory.db "PRAGMA integrity_check;"

# For MySQL, check credentials
mysql -u root -p -e "SELECT VERSION();"

# Check database URL in .env
grep DATABASE_URL .env
```

#### Solutions

```bash
# For SQLite - reset database
rm provigent_inventory.db
python app.py  # Recreates database

# For MySQL - create database
mysql -u root -p
CREATE DATABASE provigent_inventory;
SOURCE database/schema.sql;

# Check permissions
chmod 666 provigent_inventory.db  # macOS/Linux
```

### Issue 4: Authentication Issues

#### Symptoms
```
401 Unauthorized
Invalid token
Token expired
```

#### Diagnosis Steps

```bash
# Test login endpoint
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Check JWT configuration in .env
grep JWT .env

# Verify token is being sent
curl -v http://localhost:5000/api/inventory
```

#### Solutions

```bash
# Create new user
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username":"newuser",
    "email":"user@test.com",
    "password":"password123"
  }'

# Use generated token in requests
# Authorization: Bearer <token>
```

### Issue 5: API Test Failures

#### Symptoms
```
Test failed - unexpected status code
AssertionError: Expected 200, got 400
Response was not valid JSON
```

#### Diagnosis Steps

```bash
# Run test with verbose output
pytest -v -s

# Check test configuration
cat tests/conftest.py

# Verify test database
# Tests should use in-memory database

# Check response details
pytest -v --tb=long

# Enable SQL logging
export SQLALCHEMY_ECHO=1
pytest -v
```

#### Solutions

```bash
# Update test fixtures if models changed
# Ensure conftest.py creates all tables

# Check that test database is separate
SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'

# Verify mock data is created
# Use @pytest.fixture decorator properly

# Run single test first
pytest tests/test_routes_auth.py::TestAuthentication::test_login_user -v
```

---

## Performance Testing

### Load Testing with Apache Bench

```bash
# Install Apache Bench
# Ubuntu: sudo apt-get install apache2-utils
# macOS: brew install httpd

# Test endpoint with 1000 requests
ab -n 1000 -c 10 http://localhost:5000/api/inventory

# Example output:
# Requests per second:    250.05 [#/sec] (mean)
# Time per request:       40.008 [ms] (mean)
# Percentage of requests within a certain time (ms)
#  50%     30
#  90%     50
#  95%     60
#  99%     100
```

### Python Load Testing

```python
# load_test.py
import requests
import time
from concurrent.futures import ThreadPoolExecutor

BASE_URL = 'http://localhost:5000'
TOKEN = 'your_jwt_token_here'

def test_endpoint(url):
    headers = {'Authorization': f'Bearer {TOKEN}'}
    start = time.time()
    response = requests.get(url, headers=headers)
    duration = time.time() - start
    return response.status_code, duration

# Test with 100 concurrent requests
with ThreadPoolExecutor(max_workers=10) as executor:
    futures = []
    for i in range(100):
        future = executor.submit(
            test_endpoint,
            f'{BASE_URL}/api/inventory'
        )
        futures.append(future)
    
    results = [f.result() for f in futures]
    
    success = sum(1 for status, _ in results if status == 200)
    avg_time = sum(duration for _, duration in results) / len(results)
    
    print(f"Success rate: {success}/100")
    print(f"Average response time: {avg_time:.3f}s")
```

---

## Security Testing

### OWASP Top 10 Checks

#### 1. SQL Injection Test

```bash
# Try to inject SQL
curl -X GET "http://localhost:5000/api/inventory/search?query=';DROP TABLE users;--" \
  -H "Authorization: Bearer $TOKEN"

# Should return safe response, not execute SQL
```

#### 2. XSS Test

```bash
# Try to inject script
curl -X POST http://localhost:5000/api/inventory \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "<script>alert(\"XSS\")</script>",
    "sku": "TEST",
    "quantity": 100,
    "unit_price": 10.00
  }'
```

#### 3. CSRF Protection Test

```bash
# Attempt request without CSRF token
# Flask-WTF should protect against this

# Send POST without proper headers
curl -X POST http://localhost:5000/api/inventory \
  -d '{"name":"test"}'  # Should fail
```

#### 4. Authorization Test

```bash
# Try to access other users data
# Should return 403 Forbidden

TOKEN_USER1="token_for_user1"
TOKEN_USER2="token_for_user2"

# User2 tries to access User1's orders
curl -X GET http://localhost:5000/api/orders \
  -H "Authorization: Bearer $TOKEN_USER2"
```

---

## Reporting Test Results

### Generate Test Report

```bash
# HTML coverage report
pytest --cov=. --cov-report=html
# Open htmlcov/index.html in browser

# JUnit XML report
pytest --junit-xml=report.xml

# JSON report
pytest --json-report --json-report-file=report.json
```

### Example Report

```
Test Results Summary
====================
Total Tests: 145
Passed: 142 (98%)
Failed: 2 (1%)
Skipped: 1 (1%)

Failed Tests:
- test_order_delivery_date_validation
- test_supplier_duplicate_name

Coverage Report:
- Backend: 92%
- Frontend: 87%
- Overall: 90%
```

---

## Best Practices

### Testing Checklist

- [ ] Unit tests for all models
- [ ] Integration tests for all API endpoints
- [ ] Component tests for React components
- [ ] Database integrity tests
- [ ] Authentication/Authorization tests
- [ ] Error handling tests
- [ ] Load/Performance tests
- [ ] Security tests
- [ ] 90%+ code coverage

### Continuous Integration

Create `.github/workflows/tests.yml`:

```yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: 3.9
    
    - name: Install dependencies
      run: |
        pip install -r requirements.txt
        pip install pytest pytest-cov
    
    - name: Run tests
      run: pytest --cov=.
    
    - name: Upload coverage
      uses: codecov/codecov-action@v2
```

---

## Quick Reference

### Common Test Commands

| Command | Purpose |
|---------|---------|
| `pytest` | Run all tests |
| `pytest -v` | Verbose output |
| `pytest --cov` | Coverage report |
| `pytest -k test_login` | Run matching tests |
| `npm test` | Run React tests |
| `npm test -- --coverage` | React coverage |

---

**Last Updated:** August 10, 2024
