# Provigent Inventory Management System - End-to-End Documentation

**Version:** 1.0.0  
**Last Updated:** August 2024  
**Repository:** https://github.com/kumaraveldharmalingam11cs27-prog/IMS/tree/feature/test

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [System Architecture](#system-architecture)
3. [Prerequisites](#prerequisites)
4. [Installation Guide](#installation-guide)
5. [Configuration](#configuration)
6. [Running the Application](#running-the-application)
7. [API Documentation](#api-documentation)
8. [Database Schema](#database-schema)
9. [Testing](#testing)
10. [Deployment](#deployment)
11. [Troubleshooting](#troubleshooting)
12. [Contributing](#contributing)

---

## Project Overview

### What is Provigent Inventory Management System?

Provigent IMS is a complete full-stack inventory management solution designed to help organizations efficiently manage their inventory, suppliers, and orders. The system provides real-time tracking, automated alerts, and comprehensive analytics.

### Key Features

- **Real-time Inventory Tracking** - Monitor stock levels across all items
- **Order Management** - Create, track, and manage purchase orders
- **Supplier Management** - Maintain supplier database with contact information
- **Automated Alerts** - Get notified of low stock and critical inventory levels
- **Dashboard Analytics** - Visual insights into inventory performance
- **Search & Filtering** - Quickly locate inventory items
- **User Authentication** - Secure JWT-based authentication
- **Barcode Support** - Scan and manage items via barcodes

### Technology Stack

| Layer | Technology | Version |
|-------|-----------|---------|
| **Frontend** | React | 18.2.0 |
| **Frontend HTTP** | Axios | 1.5.0 |
| **Backend** | Flask | 2.3.3 |
| **Backend ORM** | SQLAlchemy | 2.0.41 |
| **Database** | SQLite/MySQL | 5.7+ |
| **Authentication** | JWT (Flask-JWT-Extended) | 4.5.2 |
| **Security** | bcrypt | 4.0.1 |
| **Server** | Gunicorn | 21.2.0 |

---

## System Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Frontend Layer                         │
│  React 18.2.0 (Port 3000)                                  │
│  ├─ Dashboard Component                                     │
│  ├─ Inventory Management UI                                │
│  ├─ Order Tracking UI                                      │
│  └─ Supplier Management UI                                 │
└────────────────────┬────────────────────────────────────────┘
                     │ HTTP/REST API
                     │ Axios HTTP Client
                     ↓
┌─────────────────────────────────────────────────────────────┐
│                      Backend Layer                          │
│  Flask 2.3.3 (Port 5000)                                   │
│  ├─ Authentication Routes (/api/auth)                      │
│  ├─ Inventory Routes (/api/inventory)                      │
│  ├─ Orders Routes (/api/orders)                            │
│  ├─ Suppliers Routes (/api/suppliers)                      │
│  ├─ Alerts Routes (/api/alerts)                            │
│  └─ Middleware (CORS, JWT, Error Handling)                 │
└────────────────────┬────────────────────────────────────────┘
                     │ SQLAlchemy ORM
                     │
                     ↓
┌─────────────────────────────────────────────────────────────┐
│                      Data Layer                             │
│  SQLite/MySQL Database                                      │
│  ├─ users table                                             │
│  ├─ inventory_items table                                   │
│  ├─ suppliers table                                         │
│  ├─ orders table                                            │
│  ├─ order_items table                                       │
│  ├─ stock_history table                                     │
│  └─ alerts table                                            │
└─────────────────────────────────────────────────────────────┘
```

### Project Directory Structure

```
IMS/
├── src/                          # React frontend source
│   ├── App.jsx                  # Main React component
│   ├── index.js                 # React entry point
│   ├── index.css                # Global styles
│   └── components/              # Reusable React components
│
├── public/                       # Static frontend files
│   └── index.html               # HTML template
│
├── app.py                        # Flask main application
├── config.py                     # Configuration settings
├── models.py                     # SQLAlchemy models
├── requirements.txt              # Python dependencies
│
├── database/
│   └── schema.sql               # Database schema
│
├── Dockerfile.backend           # Backend Docker configuration
├── Dockerfile.frontend          # Frontend Docker configuration
├── docker-compose.yml           # Docker Compose orchestration
│
├── package.json                 # Node.js dependencies
├── package-lock.json            # Locked dependency versions
│
├── .env.example                 # Environment variables template
├── README.md                     # Quick reference guide
└── setup.sh                      # Setup automation script

```

---

## Prerequisites

### System Requirements

- **Operating System:** Windows 10+, macOS 10.14+, or Ubuntu 18.04+
- **RAM:** Minimum 4GB (8GB recommended)
- **Disk Space:** Minimum 2GB free space

### Required Software

#### 1. Python 3.8+

**Windows:**
```powershell
# Download from https://www.python.org/downloads/
# Run installer and check "Add Python to PATH"
python --version
```

**macOS:**
```bash
brew install python3
python3 --version
```

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install python3 python3-pip python3-venv
python3 --version
```

#### 2. Node.js 14+

**Windows:**
```powershell
# Download from https://nodejs.org/
# Run installer
node --version
npm --version
```

**macOS:**
```bash
brew install node
node --version
npm --version
```

**Ubuntu/Debian:**
```bash
sudo apt-get install nodejs npm
node --version
npm --version
```

#### 3. Database (SQLite or MySQL)

**SQLite** (Default - No installation needed):
```bash
# SQLite is included with Python
python3 -c "import sqlite3; print(sqlite3.sqlite_version)"
```

**MySQL 5.7+** (Optional - for production):
```bash
# Windows: Download from https://dev.mysql.com/downloads/mysql/
# macOS: brew install mysql
# Ubuntu: sudo apt-get install mysql-server

mysql --version
```

#### 4. Git

**Windows:**
```powershell
# Download from https://git-scm.com/download/win
git --version
```

**macOS:**
```bash
brew install git
git --version
```

**Ubuntu/Debian:**
```bash
sudo apt-get install git
git --version
```

#### 5. Docker & Docker Compose (Optional - for containerized deployment)

**All Platforms:**
- Download from https://www.docker.com/products/docker-desktop
- Verify installation: `docker --version && docker-compose --version`

---

## Installation Guide

### Step 1: Clone the Repository

```bash
# Navigate to desired directory
cd your-projects-directory

# Clone the repository
git clone https://github.com/kumaraveldharmalingam11cs27-prog/IMS.git
cd IMS

# Switch to feature/test branch
git checkout feature/test
```

### Step 2: Backend Setup

#### 2.1 Create Virtual Environment

**Windows (PowerShell):**
```powershell
# Navigate to project root
cd IMS

# Create virtual environment
python -m venv venv

# Activate virtual environment
.\venv\Scripts\Activate.ps1

# If you get execution policy error:
# Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**macOS/Linux:**
```bash
cd IMS
python3 -m venv venv
source venv/bin/activate
```

#### 2.2 Install Python Dependencies

```bash
# Upgrade pip
pip install --upgrade pip

# Install requirements
pip install -r requirements.txt
```

**Expected Output:**
```
Successfully installed Flask-2.3.3 Flask-SQLAlchemy-3.1.1 ...
```

### Step 3: Frontend Setup

```bash
# Open a new terminal/PowerShell in the project root
# Install Node.js dependencies
npm install

# Verify installation
npm --version
node --version
```

**Expected Output:**
```
added XXX packages in XXs
```

### Step 4: Database Setup

#### 4.1 Using SQLite (Default)

SQLite database is automatically created when you run the application. No additional setup needed.

```bash
# The app.py will create provigent_inventory.db automatically
```

#### 4.2 Using MySQL (Production)

```bash
# Connect to MySQL
mysql -u root -p

# Create database and import schema
CREATE DATABASE provigent_inventory;
USE provigent_inventory;
SOURCE database/schema.sql;
EXIT;
```

**MySQL Database Credentials:**
- Host: `localhost`
- Port: `3306`
- User: `root`
- Password: (your MySQL password)
- Database: `provigent_inventory`

---

## Configuration

### Step 1: Create Environment File

```bash
# Copy example environment file
cp .env.example .env
```

### Step 2: Configure Environment Variables

Edit `.env` file with your settings:

```env
# Flask Configuration
FLASK_APP=app.py
FLASK_ENV=development
SECRET_KEY=your-secret-key-here-change-in-production

# Database Configuration (SQLite - Default)
DATABASE_URL=sqlite:///provigent_inventory.db

# Alternative: MySQL Configuration
# DATABASE_URL=mysql+pymysql://root:password@localhost/provigent_inventory

# JWT Configuration
JWT_SECRET_KEY=your-jwt-secret-key-change-in-production
JWT_ACCESS_TOKEN_EXPIRES=3600

# Server Configuration
FLASK_RUN_HOST=0.0.0.0
FLASK_RUN_PORT=5000

# Frontend Configuration
REACT_APP_API_URL=http://localhost:5000

# Security
CORS_ORIGINS=http://localhost:3000,http://localhost:5000

# Logging
LOG_LEVEL=INFO
```

### Environment Variables Explanation

| Variable | Purpose | Default | Example |
|----------|---------|---------|---------|
| `FLASK_ENV` | Environment mode (development/production) | development | production |
| `SECRET_KEY` | Flask session encryption key | - | `abc123xyz789` |
| `DATABASE_URL` | Database connection string | sqlite:///provigent_inventory.db | mysql://user:pass@host/db |
| `JWT_SECRET_KEY` | JWT token signing key | - | `jwt-secret-xyz` |
| `FLASK_RUN_PORT` | Backend server port | 5000 | 8080 |
| `REACT_APP_API_URL` | Frontend API endpoint | http://localhost:5000 | https://api.example.com |

---

## Running the Application

### Option 1: Local Development (Recommended for Setup)

#### Terminal 1 - Backend Server

**Windows (PowerShell):**
```powershell
# Navigate to project root
cd c:\Users\kveld\Downloads\files

# Activate virtual environment
.\venv\Scripts\Activate.ps1

# Run Flask app
python app.py
```

**macOS/Linux:**
```bash
cd ~/path-to-IMS
source venv/bin/activate
python app.py
```

**Expected Output:**
```
WARNING in app.runserver: This is a development server. Do not use it in production.
Running on http://127.0.0.1:5000
Press CTRL+C to quit
```

#### Terminal 2 - Frontend Development Server

**All Platforms:**
```bash
# Open new terminal in project root
npm start
```

**Expected Output:**
```
Compiled successfully!
On Your Network: http://xxx.xxx.x.xxx:3000
Local: http://localhost:3000
```

#### Access the Application

- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:5000
- **API Documentation:** http://localhost:5000/api/docs (if available)

### Option 2: Docker Compose (Production-Ready)

```bash
# Build and start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down

# Rebuild services
docker-compose up -d --build
```

**Docker Services:**
- **Frontend:** http://localhost:3000
- **Backend:** http://localhost:5000
- **Database:** Containerized SQLite or MySQL

### Option 3: Production Deployment with Gunicorn

```bash
# Activate virtual environment
source venv/bin/activate  # or .\venv\Scripts\Activate.ps1 on Windows

# Run with Gunicorn (4 workers)
gunicorn -w 4 -b 0.0.0.0:5000 app:app

# Run with more workers for higher traffic
gunicorn -w 8 -b 0.0.0.0:5000 app:app
```

---

## API Documentation

### Base URL

```
http://localhost:5000/api
```

### Authentication

All protected endpoints require JWT token in the Authorization header:

```
Authorization: Bearer <jwt_token>
```

### Response Format

**Success Response (200):**
```json
{
  "success": true,
  "data": { /* resource data */ },
  "message": "Operation successful"
}
```

**Error Response (4xx/5xx):**
```json
{
  "success": false,
  "error": "Error message",
  "status": 400
}
```

### Authentication Endpoints

#### 1. Register User

```http
POST /api/auth/register
Content-Type: application/json

{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "secure_password123"
}
```

**Response (201):**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "username": "john_doe",
    "email": "john@example.com"
  },
  "message": "User registered successfully"
}
```

#### 2. Login User

```http
POST /api/auth/login
Content-Type: application/json

{
  "username": "john_doe",
  "password": "secure_password123"
}
```

**Response (200):**
```json
{
  "success": true,
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIs...",
    "user": {
      "id": 1,
      "username": "john_doe",
      "email": "john@example.com"
    }
  }
}
```

#### 3. Logout User

```http
POST /api/auth/logout
Authorization: Bearer <jwt_token>
```

**Response (200):**
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

### Inventory Endpoints

#### 4. Get All Inventory Items

```http
GET /api/inventory
Authorization: Bearer <jwt_token>
```

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 20)
- `search` (optional): Search query

**Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "sku": "SKU-001",
      "name": "Widget A",
      "description": "High quality widget",
      "quantity": 150,
      "min_stock": 50,
      "max_stock": 500,
      "unit_price": 29.99,
      "category": "Hardware",
      "location": "Warehouse A",
      "created_at": "2024-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "total": 100,
    "page": 1,
    "limit": 20,
    "pages": 5
  }
}
```

#### 5. Get Specific Item

```http
GET /api/inventory/<id>
Authorization: Bearer <jwt_token>
```

**Response (200):**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "sku": "SKU-001",
    "name": "Widget A",
    "quantity": 150,
    "min_stock": 50,
    "unit_price": 29.99
  }
}
```

#### 6. Create Inventory Item

```http
POST /api/inventory
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "sku": "SKU-002",
  "name": "Widget B",
  "description": "Premium widget",
  "quantity": 100,
  "min_stock": 30,
  "max_stock": 400,
  "unit_price": 39.99,
  "category": "Hardware",
  "location": "Warehouse B"
}
```

**Response (201):**
```json
{
  "success": true,
  "data": {
    "id": 2,
    "sku": "SKU-002",
    "name": "Widget B"
  },
  "message": "Item created successfully"
}
```

#### 7. Update Inventory Item

```http
PUT /api/inventory/<id>
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "quantity": 120,
  "unit_price": 34.99
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Item updated successfully"
}
```

#### 8. Delete Inventory Item

```http
DELETE /api/inventory/<id>
Authorization: Bearer <jwt_token>
```

**Response (200):**
```json
{
  "success": true,
  "message": "Item deleted successfully"
}
```

#### 9. Search Inventory

```http
GET /api/inventory/search?query=widget&category=Hardware
Authorization: Bearer <jwt_token>
```

**Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "sku": "SKU-001",
      "name": "Widget A",
      "quantity": 150
    }
  ]
}
```

### Orders Endpoints

#### 10. Get All Orders

```http
GET /api/orders
Authorization: Bearer <jwt_token>
```

**Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "order_number": "ORD-2024-001",
      "supplier_id": 1,
      "order_date": "2024-01-15",
      "expected_delivery": "2024-01-22",
      "status": "pending",
      "total_amount": 1299.90,
      "items": [
        {
          "item_id": 1,
          "quantity": 10,
          "unit_price": 29.99
        }
      ]
    }
  ]
}
```

#### 11. Create Order

```http
POST /api/orders
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "supplier_id": 1,
  "expected_delivery": "2024-01-22",
  "items": [
    {
      "item_id": 1,
      "quantity": 10
    }
  ]
}
```

**Response (201):**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "order_number": "ORD-2024-001"
  }
}
```

#### 12. Update Order Status

```http
PUT /api/orders/<id>
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "status": "confirmed"
}
```

**Valid Statuses:** `pending`, `confirmed`, `shipped`, `delivered`, `cancelled`

**Response (200):**
```json
{
  "success": true,
  "message": "Order status updated"
}
```

### Suppliers Endpoints

#### 13. Get All Suppliers

```http
GET /api/suppliers
Authorization: Bearer <jwt_token>
```

**Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "Quality Supplies Inc.",
      "contact_email": "contact@qualitysupplies.com",
      "phone": "+1-555-0123",
      "lead_time_days": 7,
      "payment_terms": "Net 30"
    }
  ]
}
```

#### 14. Create Supplier

```http
POST /api/suppliers
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "name": "New Supplier Ltd.",
  "contact_email": "info@newsupplier.com",
  "phone": "+1-555-0456",
  "lead_time_days": 5,
  "payment_terms": "Net 15"
}
```

**Response (201):**
```json
{
  "success": true,
  "data": {
    "id": 2,
    "name": "New Supplier Ltd."
  }
}
```

### Alerts Endpoints

#### 15. Get Active Alerts

```http
GET /api/alerts
Authorization: Bearer <jwt_token>
```

**Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "type": "low_stock",
      "item_id": 1,
      "item_name": "Widget A",
      "current_quantity": 45,
      "min_stock": 50,
      "severity": "warning",
      "created_at": "2024-01-15T10:30:00Z"
    }
  ]
}
```

#### 16. Dismiss Alert

```http
POST /api/alerts/<id>/dismiss
Authorization: Bearer <jwt_token>
```

**Response (200):**
```json
{
  "success": true,
  "message": "Alert dismissed"
}
```

---

## Database Schema

### Users Table

```sql
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(80) UNIQUE NOT NULL,
  email VARCHAR(120) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  is_active BOOLEAN DEFAULT TRUE
);
```

### Inventory Items Table

```sql
CREATE TABLE inventory_items (
  id INT PRIMARY KEY AUTO_INCREMENT,
  sku VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(200) NOT NULL,
  description TEXT,
  quantity INT NOT NULL DEFAULT 0,
  min_stock INT DEFAULT 10,
  max_stock INT DEFAULT 1000,
  unit_price DECIMAL(10, 2),
  category VARCHAR(100),
  location VARCHAR(100),
  barcode VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### Suppliers Table

```sql
CREATE TABLE suppliers (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(200) NOT NULL,
  contact_email VARCHAR(120),
  phone VARCHAR(20),
  address TEXT,
  lead_time_days INT DEFAULT 7,
  payment_terms VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### Orders Table

```sql
CREATE TABLE orders (
  id INT PRIMARY KEY AUTO_INCREMENT,
  order_number VARCHAR(50) UNIQUE NOT NULL,
  supplier_id INT NOT NULL,
  order_date DATE NOT NULL,
  expected_delivery DATE,
  status VARCHAR(50) DEFAULT 'pending',
  total_amount DECIMAL(10, 2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (supplier_id) REFERENCES suppliers(id)
);
```

### Order Items Table

```sql
CREATE TABLE order_items (
  id INT PRIMARY KEY AUTO_INCREMENT,
  order_id INT NOT NULL,
  item_id INT NOT NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(10, 2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (item_id) REFERENCES inventory_items(id)
);
```

### Stock History Table

```sql
CREATE TABLE stock_history (
  id INT PRIMARY KEY AUTO_INCREMENT,
  item_id INT NOT NULL,
  previous_quantity INT,
  new_quantity INT,
  change_reason VARCHAR(100),
  changed_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (item_id) REFERENCES inventory_items(id),
  FOREIGN KEY (changed_by) REFERENCES users(id)
);
```

### Alerts Table

```sql
CREATE TABLE alerts (
  id INT PRIMARY KEY AUTO_INCREMENT,
  item_id INT NOT NULL,
  alert_type VARCHAR(50),
  severity VARCHAR(20) DEFAULT 'warning',
  message TEXT,
  is_dismissed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (item_id) REFERENCES inventory_items(id)
);
```

---

## Testing

### Backend Testing

#### Unit Tests

```bash
# Activate virtual environment
source venv/bin/activate  # macOS/Linux
# or
.\venv\Scripts\Activate.ps1  # Windows

# Install pytest
pip install pytest pytest-cov

# Run tests
pytest

# Run with coverage report
pytest --cov=.
```

#### Testing API Endpoints

**Using curl:**
```bash
# Test login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Get inventory (with token)
curl -X GET http://localhost:5000/api/inventory \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Using Postman:**
1. Import API endpoints from documentation
2. Set up environment variables for token storage
3. Create test collections for each feature

### Frontend Testing

#### Component Tests

```bash
# Run tests
npm test

# Run with coverage
npm test -- --coverage

# Run specific test file
npm test -- inventory.test.js
```

#### E2E Testing

```bash
# Install Cypress
npm install --save-dev cypress

# Open Cypress
npx cypress open

# Run headless
npx cypress run
```

### Load Testing

**Using Apache Bench:**
```bash
# Test 1000 requests with 10 concurrent
ab -n 1000 -c 10 http://localhost:5000/api/inventory
```

---

## Deployment

### Production Checklist

- [ ] Change `FLASK_ENV` to `production`
- [ ] Generate strong `SECRET_KEY` and `JWT_SECRET_KEY`
- [ ] Set `DEBUG = False`
- [ ] Configure production database (MySQL)
- [ ] Enable HTTPS/SSL
- [ ] Set up database backups
- [ ] Configure logging and monitoring
- [ ] Enable rate limiting
- [ ] Set up email notifications
- [ ] Configure CORS for production domain
- [ ] Test all API endpoints
- [ ] Set up CI/CD pipeline

### Deployment Options

#### 1. Heroku Deployment

```bash
# Install Heroku CLI
# Create Procfile
echo "web: gunicorn app:app" > Procfile

# Deploy
heroku login
heroku create your-app-name
git push heroku main
```

#### 2. AWS Deployment

```bash
# Use AWS Elastic Beanstalk
eb init
eb create
eb deploy
```

#### 3. DigitalOcean Deployment

```bash
# Create Droplet (Ubuntu 20.04)
# SSH into droplet
ssh root@your_server_ip

# Install dependencies
apt-get update
apt-get install python3 python3-pip python3-venv nodejs npm

# Clone and setup project
git clone https://github.com/kumaraveldharmalingam11cs27-prog/IMS.git
cd IMS
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
npm install
```

#### 4. Docker Deployment

```bash
# Build images
docker-compose build

# Run containers
docker-compose up -d

# View logs
docker-compose logs -f
```

### Performance Optimization

**Backend:**
```python
# Enable caching
from flask_caching import Cache
cache = Cache(app, config={'CACHE_TYPE': 'simple'})

@app.route('/api/inventory')
@cache.cached(timeout=300)
def get_inventory():
    # ... code
```

**Frontend:**
```javascript
// Code splitting
const Dashboard = React.lazy(() => import('./Dashboard'));

// Lazy loading
<Suspense fallback={<Loading />}>
  <Dashboard />
</Suspense>
```

---

## Troubleshooting

### Common Issues and Solutions

#### 1. Virtual Environment Not Activating

**Problem:** `The term '.\venv\Scripts\Activate.ps1' is not recognized`

**Solution (Windows PowerShell):**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
.\venv\Scripts\Activate.ps1
```

#### 2. Port Already in Use

**Problem:** `Address already in use`

**Solution - Windows:**
```powershell
# Find process using port 5000
netstat -ano | findstr :5000

# Kill process (replace PID with actual process ID)
taskkill /PID <PID> /F
```

**Solution - macOS/Linux:**
```bash
# Find and kill process
lsof -ti:5000 | xargs kill -9
```

#### 3. Module Not Found Error

**Problem:** `ModuleNotFoundError: No module named 'flask'`

**Solution:**
```bash
# Activate virtual environment
source venv/bin/activate  # or .\venv\Scripts\Activate.ps1

# Reinstall dependencies
pip install -r requirements.txt
```

#### 4. Database Connection Error

**Problem:** `Can't connect to database server`

**Solution:**
```bash
# Check database URL in .env
cat .env | grep DATABASE_URL

# For MySQL, verify server is running
mysql -u root -p

# For SQLite, check file permissions
ls -la provigent_inventory.db
```

#### 5. CORS Error

**Problem:** `Access to XMLHttpRequest has been blocked by CORS policy`

**Solution:**
```python
# In app.py, update CORS configuration
CORS(app, resources={
    r"/api/*": {
        "origins": ["http://localhost:3000"],
        "methods": ["GET", "POST", "PUT", "DELETE"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})
```

#### 6. npm Install Hangs

**Problem:** `npm install` stops or hangs

**Solution:**
```bash
# Clear cache
npm cache clean --force

# Set registry
npm set registry https://registry.npmjs.org/

# Retry install
npm install
```

#### 7. React Port 3000 Already in Use

**Problem:** `Port 3000 is already in use`

**Solution:**
```bash
# Use different port
PORT=3001 npm start

# Or kill process on port 3000
# Windows: taskkill /PID <PID> /F
# macOS/Linux: lsof -ti:3000 | xargs kill -9
```

### Debug Mode

**Backend:**
```python
# In app.py
app.run(debug=True, host='0.0.0.0', port=5000)
```

**Frontend:**
```bash
# Enable verbose output
npm start -- --verbose

# React DevTools browser extension
```

### Logging

**Backend:**
```python
import logging

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
```

**Frontend:**
```javascript
// Enable console logging
console.log('Debug info:', variable);
```

---

## Contributing

### Getting Started with Development

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/your-feature`
3. Follow the setup guide above
4. Make your changes
5. Test thoroughly
6. Commit with clear messages: `git commit -m "Add feature description"`
7. Push to branch: `git push origin feature/your-feature`
8. Submit a Pull Request

### Code Standards

#### Python (Backend)
- Follow PEP 8 style guide
- Use type hints for functions
- Write docstrings for all functions

```python
def get_inventory_by_id(item_id: int) -> dict:
    """
    Retrieve inventory item by ID.
    
    Args:
        item_id: The ID of the inventory item
        
    Returns:
        Dictionary containing item details
    """
    pass
```

#### JavaScript/React (Frontend)
- Follow ESLint configuration
- Use meaningful component names
- Add PropTypes for components

```jsx
import PropTypes from 'prop-types';

function InventoryItem({ item, onUpdate }) {
  return <div>{item.name}</div>;
}

InventoryItem.propTypes = {
  item: PropTypes.object.isRequired,
  onUpdate: PropTypes.func.isRequired
};
```

### Commit Message Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types:** feat, fix, docs, style, refactor, test, chore

**Example:**
```
feat(inventory): add barcode scanning feature

Implement barcode scanning functionality with validation
and automatic item lookup.

Closes #123
```

### Pull Request Template

```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change

## Testing
- [ ] Unit tests added
- [ ] Manual testing done

## Screenshots/Logs
(If applicable)
```

---

## Support & Resources

### Documentation Files

- `README.md` - Quick reference
- `INSTALLATION_GUIDE.md` - Detailed setup
- `API_DOCUMENTATION.md` - API endpoints
- `PROJECT_SUMMARY.md` - Project overview

### External Resources

- [Flask Documentation](https://flask.palletsprojects.com/)
- [React Documentation](https://react.dev/)
- [SQLAlchemy Documentation](https://docs.sqlalchemy.org/)
- [Axios Documentation](https://axios-http.com/)
- [JWT Authentication Guide](https://jwt.io/)

### Getting Help

1. **Check Documentation** - Review the docs first
2. **Search Issues** - Look for existing bug reports
3. **Create Issue** - Describe the problem in detail
4. **Contact Support** - support@provigent.com

---

## License

This project is licensed under the MIT License. See LICENSE file for details.

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | Aug 2024 | Initial release |
| 0.9.0 | Jul 2024 | Beta version |

---

**Last Updated:** August 10, 2024  
**Next Review:** October 10, 2024

For the latest updates, visit: https://github.com/kumaraveldharmalingam11cs27-prog/IMS/tree/feature/test
